%parameters
epsilon=8.854*10^-14; %F/cm^2
epsilonsi=11.8;
epsilonox=3.9;
epsi=epsilon*epsilonsi;
epox=epsilon*epsilonox;
k=1.38*10^-23; %J/K Boltzmann Constant
T=300; %Kelvin
NA=10^17; %cm^-3
ni=1.5*10^10;
tox=5*10^-7; %cm
Cox=epox/tox;
q=1.6*10^-19;
k1=q/(k*T); 
k2=ni^2/NA^2;
phif=(1/k1)*log(NA/ni);
Eg=1.1;
Ei=Eg/2;
Vfb=-(Eg/2+phif);
coeff=sqrt(2*epsi*k*T*NA);
vth=2.6e7; %thermal velocity
sigma=1e-15; %capture cross-section
E1=-(Ei-phif);
E2=Ei+phif;
psi = linspace(E1, E2, 270);
tt=0;
for i=1:270
    if (psi(i) > 0) && (tt==0)
        tt=i;
    end;
end;

eit=-psi;
%taking derivative manually and putting the expression
    Cs=-(coeff.*(((exp(-k1.*psi)+psi.*k1-1)+k2.*(exp(k1.*psi)-psi.*k1-1)).^(-0.5)).*((-k1.*exp(-k1.*psi)+k1)+k2.*(k1.*exp(k1.*psi)-k1)))./2;
    Cs(tt:270)=-Cs(tt:270);
    C1=((1./Cox)+(1./Cs));
    C=1./C1;

%calculating charge
    Q=coeff.*(((exp(-k1.*psi)+psi.*k1-1)+k2.*(exp(k1.*psi)-psi.*k1-1)).^0.5);
    Q(tt:270)=-Q(tt:270);
    Vg=Vfb+psi-(Q./Cox);
   % figure(1);
    hold all
plot(Vg, C);


A1=6e12;
A2=6e12;
A3=2e12;
B1=0.1;
B2=0.97; 
B3=0.5; 
C1=0.2;
C2=0.2;
C3=0.5;

dit=(A1.*exp(-((eit-B1)./C1).^2))+(A2.*exp(-((eit-B2)./C2).^2))+(A3.*exp(-((eit-B3)./C3).^2));
tau=(exp(-q*(abs(eit-Ei))./(k.*T)))./(sigma.*ni.*vth); %trap time constant
w= 10^3 ; %omega

for i=1:4
    Cit=q.*dit;

    Gp=w.*q.*dit.*w.*tau./(1+((w.*tau).^2));
   
    Cp=Cs+(Cit./(1+((w.*tau).^2)));
    num=(Cox.*((Gp).^2))+(Cp.*((w.*Cox).^2))+(Cox.*((Cp.*w).^2));
    den=((Gp).^2)+((w.^2).*((Cp+Cox).^2));
    Cm=num./den;
%Cmavg=(int(Cm, eit, 0, 1.1)); %/1.1 ?
    Gm=((Cox-Cm).*Gp)./(Cp+Cox);
%Gmavg=(int(Gm, eit, 0, 1.1)); %/1.1 ?
    plot(Vg, Cm);
    hold on;
    w=w*100;
end

legend('ideal', 'w=10^3', 'w=10^4', 'w=10^5', 'w=10^6');
hold off;
xlabel("Vg");
%ylabel("C/Cox"); 
ylabel("C in F");
grid on;